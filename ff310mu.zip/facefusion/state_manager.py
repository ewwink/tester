from typing import Any, Union

import gradio

from facefusion.app_context import detect_app_context
from facefusion.processors.typing import ProcessorState, ProcessorStateKey
from facefusion.typing import State, StateKey, StateSet
import copy

SESSION_HASH = None

STATES : Union[StateSet, ProcessorState] =\
{
	'cli': {}, #type:ignore[typeddict-item]
	'ui': {} #type:ignore[typeddict-item]
}

def set_session(session_hash):
	global SESSION_HASH
	SESSION_HASH = session_hash
	if session_hash not in STATES:
		STATES[SESSION_HASH] = {
			'cli': copy.deepcopy(STATES['cli']),
			'ui': copy.deepcopy(STATES['ui'])
		}

def get_state() -> Union[State, ProcessorState]:
	global SESSION_HASH
	app_context = detect_app_context()
	if SESSION_HASH:
		return STATES[SESSION_HASH].get(app_context) #type:ignore
	else:
		return STATES.get(app_context) #type:ignore


def init_item(key : Union[StateKey, ProcessorStateKey], value : Any) -> None:
	global SESSION_HASH
	if SESSION_HASH:
		STATES[SESSION_HASH]['cli'][key] = value #type:ignore
		STATES[SESSION_HASH]['ui'][key] = value #type:ignore
	else:
		STATES['cli'][key] = value #type:ignore
		STATES['ui'][key] = value #type:ignore


def get_item(key : Union[StateKey, ProcessorStateKey]) -> Any:
	return get_state().get(key) #type:ignore


def set_item(key : Union[StateKey, ProcessorStateKey], value : Any) -> None:
	global SESSION_HASH
	if SESSION_HASH:
		app_context = detect_app_context()
		STATES[SESSION_HASH][app_context][key] = value #type:ignore
	else:
		app_context = detect_app_context()
		STATES[app_context][key] = value #type:ignore


def sync_item(key : Union[StateKey, ProcessorStateKey]) -> None:
	global SESSION_HASH
	if SESSION_HASH:
		STATES[SESSION_HASH]['cli'][key] = STATES.get('ui').get(key) #type:ignore
	else:
		STATES[SESSION_HASH]['cli'][key] = STATES.get('ui').get(key)


def clear_item(key : Union[StateKey, ProcessorStateKey]) -> None:
	set_item(key, None)
