import hashlib
from typing import List, Optional

import numpy

from facefusion.typing import Face, FaceSet, FaceStore, VisionFrame

SESSION_HASH = None
FACE_STORE : FaceStore =\
{
	'static_faces': {},
	'reference_faces': {}
}


def get_face_store() -> FaceStore:
	return FACE_STORE

def face_store_set_session(session_hash):
	global SESSION_HASH
	SESSION_HASH = session_hash
	if session_hash:
		if session_hash not in FACE_STORE:
			FACE_STORE[SESSION_HASH] = {
				'static_faces': {},
				'reference_faces': {}
			}
	else:
		print("session: none")

def get_static_faces(vision_frame : VisionFrame) -> Optional[List[Face]]:
	global SESSION_HASH
	frame_hash = create_frame_hash(vision_frame)
	if SESSION_HASH and frame_hash in FACE_STORE[SESSION_HASH]['static_faces']:
		return FACE_STORE[SESSION_HASH]['static_faces'][frame_hash]
	return None


def set_static_faces(vision_frame : VisionFrame, faces : List[Face]) -> None:
	global SESSION_HASH
	frame_hash = create_frame_hash(vision_frame)
	if frame_hash:
		FACE_STORE[SESSION_HASH]['static_faces'][frame_hash] = faces


def clear_static_faces() -> None:
	global SESSION_HASH
	if SESSION_HASH:
		FACE_STORE[SESSION_HASH]['static_faces'] = {}
	else:
		FACE_STORE['static_faces'] = {}


def create_frame_hash(vision_frame : VisionFrame) -> Optional[str]:
	return hashlib.sha1(vision_frame.tobytes()).hexdigest() if numpy.any(vision_frame) else None


def get_reference_faces() -> Optional[FaceSet]:
	global SESSION_HASH
	if SESSION_HASH and FACE_STORE[SESSION_HASH]['reference_faces']:
		return FACE_STORE[SESSION_HASH]['reference_faces']
	return None


def append_reference_face(name : str, face : Face) -> None:
	global SESSION_HASH
	if not SESSION_HASH:
		return
	if name not in FACE_STORE[SESSION_HASH]['reference_faces']:
		FACE_STORE[SESSION_HASH]['reference_faces'][name] = []
	FACE_STORE[SESSION_HASH]['reference_faces'][name].append(face)


def clear_reference_faces() -> None:
	global SESSION_HASH
	if SESSION_HASH:
		FACE_STORE[SESSION_HASH]['reference_faces'] = {}
	else:
		FACE_STORE['reference_faces'] = {}
